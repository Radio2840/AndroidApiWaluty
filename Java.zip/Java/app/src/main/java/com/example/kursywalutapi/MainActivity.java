package com.example.kursywalutapi;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.kursywalutapi.api.CurrencyBitAskResponse;
import com.example.kursywalutapi.api.CurrencyResponse;
import com.example.kursywalutapi.api.Rate;
import com.example.kursywalutapi.services.NbpApiService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    private TextView ratesView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        ratesView = findViewById(R.id.rateView);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://api.nbp.pl/api/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        NbpApiService nbpApiService = retrofit.create(NbpApiService.class);
        String[] currencyCodes = getResources().getStringArray(R.array.ISO4217Abbereviation);
        String[] currency = getResources().getStringArray(R.array.ISO4217);
        Map<String, String> currencyMap = new HashMap<String, String>();
        for (int i = 0; i < currencyCodes.length; i++) {
            currencyMap.put(currencyCodes[i], currency[i]);
        }
        Spinner spinner = findViewById(R.id.currencySpiner);
        TextView bitAskView = findViewById(R.id.bitAskView);




        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String StringValue = getResources().getStringArray(R.array.ISO4217Abbereviation)[(int) l];
                Pattern pattern = Pattern.compile("\\((.*?)\\)");
                String code;
                Matcher matcher = pattern.matcher(StringValue);
                if(matcher.find()) {
                    code = matcher.group(1);
                }
                else {
                    code = "USD";
                }
                nbpApiService.getExchangeRate(code).enqueue(new Callback<CurrencyResponse>() {
                    @Override
                    public void onResponse(Call<CurrencyResponse> call, Response<CurrencyResponse> response) {
                        CurrencyResponse currencyResponse = response.body();
                        if(currencyResponse != null && currencyResponse.getRates() != null && !currencyResponse.getRates().isEmpty()) {
                            double exchangeRate = currencyResponse.getRates().get(0).getMid();
                            String currencyName = currencyResponse.getCurrency();
                            ratesView.setText(String.format("%s: %.4f", currencyName, exchangeRate));
                        }
                    }

                    @Override
                    public void onFailure(Call<CurrencyResponse> call, Throwable throwable) {
                        Log.e("API Error", "Błąd podczas pobierania danych: " + throwable.getMessage());
                        ratesView.setText("Nie udało się pobrać danych 🥰");
                    }
                });
                nbpApiService.getBitAsk(code).enqueue(new Callback<CurrencyBitAskResponse>() {
                    @Override
                    public void onResponse(Call<CurrencyBitAskResponse> call, Response<CurrencyBitAskResponse> response) {
                        CurrencyBitAskResponse currencyBitAskResponse = response.body();
                        if(currencyBitAskResponse != null && currencyBitAskResponse.getRates() != null && !currencyBitAskResponse.getRates().isEmpty()) {
                            double bitRate = currencyBitAskResponse.getRates().get(0).getBid();
                            double askRate = currencyBitAskResponse.getRates().get(0).getAsk();
                            String currencyName = currencyBitAskResponse.getCurrency();
                            bitAskView.setText(String.format("%s: bit %.4f, ask: %.4f", currencyName, bitRate, askRate));
                        }
                    }

                    @Override
                    public void onFailure(Call<CurrencyBitAskResponse> call, Throwable throwable) {
                        Log.e("API Error", "Błąd podczas pobierania danych: " + throwable.getMessage());
                        ratesView.setText("Nie udało się pobrać danych 🥰");
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }
}