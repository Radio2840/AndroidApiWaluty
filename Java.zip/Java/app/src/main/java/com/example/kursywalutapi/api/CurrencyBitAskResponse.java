package com.example.kursywalutapi.api;

import java.util.List;

public class CurrencyBitAskResponse {
    private String table;
    private String currency;
    private String code;
    private List<RateBitAsk> rates;

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public List<RateBitAsk> getRates() {
        return rates;
    }

    public void setRates(List<RateBitAsk> rates) {
        this.rates = rates;
    }
}
